﻿namespace BlogEngine.DataModels.Models
{
    public class SecuritySetting
    {
        public string SecrectKey { get; set; }

        public string PasswordSalt { get; set; }
    }
}