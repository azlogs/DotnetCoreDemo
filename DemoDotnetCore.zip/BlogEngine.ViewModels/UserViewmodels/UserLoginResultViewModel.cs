﻿namespace BlogEngine.ViewModels.UserViewmodels
{
    public class UserLoginResultViewModel
    {
        public string Token { get; set; }
    }
}