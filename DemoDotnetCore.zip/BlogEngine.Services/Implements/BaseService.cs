﻿using BlogEngine.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace BlogEngine.Services.Implements
{
    public class BaseService : IBaseService
    {
    }
}
