﻿using AspNetCore.ServiceRegistration.Dynamic.Interfaces;

namespace BlogEngine.Services.Interfaces
{
    public interface IBaseService : IScopedService
    {
    }
}